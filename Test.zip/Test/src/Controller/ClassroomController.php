<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Classroom;
use App\Form\ClassroomType;
use App\Form\EditclassroomType;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\ClassroomRepository;

class ClassroomController extends AbstractController
{    #[Route('/classroom/delete/{id}', name: 'app_classroom_delete')]
     public function delete($id ,EntityManagerInterface $entityManagerInterface , ClassroomRepository $authorRepository)
{
   $author = $authorRepository->find($id);
   $entityManagerInterface->remove($author);
   $entityManagerInterface->flush();
   return $this->redirectToRoute('app_classroom');
   dd($author);
   
}
#[Route('/classroom/fedit/{id}', name: 'app_classroom_fedit')]
public function fedit(Request $request,$id ,EntityManagerInterface $entityManagerInterface , ClassroomRepository $authorRepository)
{
   $author = $authorRepository->find($id);
   $form=$this->createForm(EditclassroomType::class,$author);
   $form->handleRequest($request);
   if($form->isSubmitted())
   {
   $entityManagerInterface->persist($author);
   $entityManagerInterface->flush();
   return $this->redirectToRoute('app_classroom');
   }
   return $this->renderForm('classroom/new1.html.twig',['form'=>$form, 'info'=>'Edit Classroom']);
   dump($author);
   die();
}
    
    #[Route('/classroom/fnew', name: 'app_classroom_fnew')]
    public function fnew(Request $request , EntityManagerInterface $entityManagerInterface)
    {
       $author = new Classroom();
       
       $form=$this->createForm(ClassroomType::class,$author);
       $form->handleRequest($request);
       if($form->isSubmitted()){
       $entityManagerInterface->persist($author);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_classroom');
       }
       return $this->renderForm('classroom/new1.html.twig',['form'=>$form,'info'=>'Add Classroom']);
      // dump($author);
      // die();
    }
    #[Route('/classroom', name: 'app_classroom')]
    public function index(ClassroomRepository $authorRepository): Response
    { 
        $authorss=$authorRepository->findAll();

        return $this->render('classroom/index2.html.twig', [
            'controller_name' => 'ClassroomController',
            'authors' => $authorss,
        ]);
    }
}