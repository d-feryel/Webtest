<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Student;
use App\Form\StudentType;
use App\Form\EditstudentType;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\StudentRepository;

class StudentController extends AbstractController
{   
    #[Route('/student/delete/{id}', name: 'app_student_delete')]
    public function delete($id ,EntityManagerInterface $entityManagerInterface , StudentRepository $authorRepository)
    {
       $author = $authorRepository->find($id);
       $entityManagerInterface->remove($author);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_student');
       dd($author);
       
    }
    #[Route('/student/fedit/{id}', name: 'app_student_fedit')]
    public function fedit(Request $request,$id ,EntityManagerInterface $entityManagerInterface , StudentRepository $authorRepository)
    {
       $author = $authorRepository->find($id);
       $form=$this->createForm(EditstudentType::class,$author);
       $form->handleRequest($request);
       if($form->isSubmitted())
       {
       $entityManagerInterface->persist($author);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_student');
       }
       return $this->renderForm('student/new.html.twig',['form'=>$form, 'info'=>'Edit Student']);
       dump($author);
       die();
    }
    #[Route('/student/fnew', name: 'app_student_fnew')]
    public function fnew(Request $request , EntityManagerInterface $entityManagerInterface)
    {
       $author = new Student();
       
       $form=$this->createForm(StudentType::class,$author);
       $form->handleRequest($request);
       if($form->isSubmitted()){
       $entityManagerInterface->persist($author);
       $entityManagerInterface->flush();
       return $this->redirectToRoute('app_student');
       }
       return $this->renderForm('student/new.html.twig',['form'=>$form,'info'=>'Add Student']);
      // dump($author);
      // die();
    }
    #[Route('/student', name: 'app_student')]
    public function index(StudentRepository $authorRepository): Response
    {   
        $authorss=$authorRepository->findAll();

        return $this->render('student/index3.html.twig', [
            'controller_name' => 'StudentController',
            'authors' => $authorss,
        ]);
    }
}